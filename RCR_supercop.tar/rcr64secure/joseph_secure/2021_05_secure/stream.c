#include "crypto_stream.h"

#include <stdio.h>
#include <string.h>

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#define YSIZE 260
#define PSIZE 256
#define YMININD (-3)
#define YMAXIND (256)
#define NUMBLOCKSATONCE 4000

#define U32V(v) ((u32)(v) & (u32)(0xFFFFFFFF))
#define ROTL32(v, n) (U32V((v) << (n)) | ((v) >> (32 - (n))))

/* This is a permutation of all the values between 0 and 255, */
/* used by the key setup and IV setup.                        */

u8 IP[256]={0x00, 0x08, 0x4a, 0x3e, 0x0a, 0x2a, 0xcd, 0x8c, \
0xd5, 0x2d, 0x2b, 0x7c, 0xfb, 0xd6, 0xe0, 0xbb, 0xa1, 0xdc, \
0x02, 0x34, 0x98, 0x92, 0x8e, 0xaf, 0xbc, 0x32, 0xee, 0xa7, \
0xea, 0x36, 0x05, 0x70, 0x50, 0xf6, 0xa8, 0x37, 0x19, 0x62, \
0x69, 0xcb, 0x0c, 0x11, 0xe9, 0x81, 0xc7, 0xae, 0x64, 0x6e, \
0x42, 0x27, 0xdf, 0x47, 0xe4, 0x1b, 0x59, 0x13, 0xac, 0xb1, \
0xd2, 0x0e, 0x95, 0xaa, 0x18, 0x29, 0x74, 0xc1, 0x57, 0x3a, \
0x38, 0x65, 0x99, 0xbf, 0xb3, 0x41, 0x8f, 0x40, 0xf0, 0x25, \
0xb8, 0x1d, 0x14, 0x7f, 0x91, 0x16, 0x09, 0xf7, 0x06, 0xb6, \
0x31, 0x6b, 0xc0, 0x5e, 0x35, 0x17, 0xd9, 0xd7, 0xcc, 0x01, \
0xb2, 0x75, 0x3f, 0x78, 0x21, 0x9f, 0xe3, 0x4b, 0x45, 0x3c, \
0x49, 0xbe, 0xa4, 0xc5, 0x6d, 0x12, 0x72, 0x4f, 0xfc, 0x5f, \
0x61, 0xc4, 0x76, 0x48, 0xfa, 0xad, 0x10, 0x7d, 0xfe, 0x56, \
0x71, 0x84, 0x79, 0x53, 0x30, 0x9d, 0x1c, 0x6c, 0x7a, 0x73, \
0xed, 0xe1, 0xd1, 0x8a, 0xda, 0x46, 0x5b, 0x4d, 0xe7, 0x04, \
0x0b, 0xa3, 0x26, 0xce, 0xf1, 0x1f, 0xb5, 0x8b, 0x20, 0xd8, \
0x85, 0x4c, 0xdd, 0xe8, 0x63, 0x9b, 0xc2, 0xdb, 0xf3, 0xe6, \
0xe2, 0x6f, 0xeb, 0xb0, 0xd3, 0x24, 0x5a, 0x7b, 0x77, 0x9a, \
0xf2, 0x2f, 0x68, 0x0f, 0xf5, 0x82, 0x67, 0x60, 0x2c, 0x9c, \
0x9e, 0x93, 0x90, 0xb7, 0x97, 0x3b, 0xba, 0x15, 0x07, 0x54, \
0x6a, 0xd0, 0xb9, 0xa0, 0x96, 0x03, 0x23, 0xcf, 0xf8, 0x66, \
0xf9, 0x8d, 0xfd, 0xbd, 0x94, 0xef, 0xde, 0x4e, 0x1a, 0x22, \
0xe5, 0x3d, 0x2e, 0xca, 0x52, 0xc9, 0x43, 0xd4, 0xa5, 0x5d, \
0xc8, 0x83, 0xf4, 0x5c, 0xa9, 0xa2, 0x33, 0xb4, 0xc3, 0xc6, \
0x7e, 0x86, 0x39, 0x0d, 0x55, 0xab, 0xff, 0x58, 0x1e, 0x44, \
0xec, 0x28, 0x80, 0x87, 0xa6, 0x89, 0x88, 0x51};

u32 mask_vector;
u8 mask_bit;

void mask_setup(void){
    u32 y = mask_vector ^ 0x1A2B3C4D ;
    u32 x = (1 << 30) | (mask_bit << 31);
    u32 z = x + y;
}

void mask(void){
    u32 x = (1 << 30) | (mask_bit << 31);
    u32 z = x + mask_vector;
}

void setup(
  u8* ctx, 
  const u8* key, 
  const u8* iv)
{ 
  u32 i, j;
  u32 s;

  u32 keysize = 256;
  u32 ivsize = 384;
  u32 kb=32;
  u32 ivb=48;

  u32 SY[260*2];
  u8 SP[260+256];

  #define Y(x) (SY[(x)-(YMININD)])
  #define P(x) (SP[(x)])

 
  s = (u32)IP[kb-1];
  s = (s<<8) | (u32)IP[(s ^ (ivb-1))&0xFF];
  s = (s<<8) | (u32)IP[(s ^ key[0])&0xFF];
  s = (s<<8) | (u32)IP[(s ^ key[kb-1])&0xFF];


  for(j=0; j<kb; j++)
    {
      s = s + key[j];
      u8 s0 = IP[s&0xFF];
      s = ROTL32(s, 8) ^ (u32)s0;
    }

  for(j=0; j<kb; j++)
    {
      s = s + key[j];
      u8 s0 = IP[s&0xFF];
      s ^= ROTL32(s, 8) + (u32)s0;
    }

  for(i=YMININD, j=0; i<=YMAXIND; i++)
    {
      s = s + key[j];
      u8 s0 = IP[s&0xFF];
      s = ROTL32(s, 8) ^ (u32)s0;
      Y(i) = s;
      j++;
      if(j<kb)
		continue;
      j=0;
    }

  u8 EIV[ivb+260];

  /* Create an initial permutation */
  u8 v= iv[0] ^ ((Y(0)>>16)&0xFF);
  u8 d=(iv[1%ivb] ^ ((Y(1)>>16)&0xFF))|1;
  for(i=0; i<256; i++)
    {
      P(i)=IP[v];
      v+=d;
    }


  /* Initial s */
  s = ((u32)v<<24)^((u32)d<<16)^((u32)P(254)<<8)^((u32)P(255));
  s ^= Y(YMININD)+Y(YMAXIND);
  for(i=0; i<ivb; i++)
    {
      s = s + iv[i] + Y(YMININD+i);
      u8 s0 = P(s&0xFF);
      EIV[i] = s0;
      s = ROTL32(s, 8) ^ (u32)s0;
    }
  /* Again, but with the last words of Y, and update EIV */
  for(i=0; i<ivb; i++)
    {
      s = s + EIV[(i+ivb-1)%ivb] + Y(YMAXIND-i);
      u8 s0 = P(s&0xFF);
      EIV[i] += s0;
      s = ROTL32(s, 8) ^ (u32)s0;
    }

  mask_bit = s%2;

  for(i=0; i<YSIZE; i++)
    {
      u32 x0 = EIV[i+ivb] = EIV[i]^(s&0xFF);
      P(i+256)=P(i+x0);
      P(i+x0)=P(i+0);
      s=ROTL32(s,8)+Y(i+YMAXIND);
      Y(i+YMAXIND+1) = Y(i+YMININD) + (s^Y(i+x0));
    }

  mask_vector = SY[YSIZE-1] ^ SY[YSIZE-2];

  s=s+Y(i+26)+Y(i+153)+Y(i+208);
  if(s==0)
    s=keysize+(ivsize<<16)+0x87654321;
  memcpy(ctx, &SY[YSIZE], YSIZE*4);
  memcpy(ctx+(260*4), &SP[YSIZE], PSIZE);
  ((u32*)ctx)[260+(256/4)]=s;

  mask_setup();
}
#undef P
#undef Y


int crypto_stream(
       unsigned char *out,
       unsigned long long outlen,
       const unsigned char *n,
       const unsigned char *k
     )
{
    u8 ctx[(4*260)+256+4];
    setup(ctx, k, n);

    u32 i,j;
    u64 length = outlen;

    u32 s=((u32*)ctx)[260+(256/4)];
    u32 EY[YSIZE+NUMBLOCKSATONCE];
    u8 EP[PSIZE+NUMBLOCKSATONCE];
    #define Y(x) (EY[(x)-(YMININD)])
    #define P(x) (EP[(x)])

  
    while(length>=NUMBLOCKSATONCE*8)
    {
        memcpy(EY, ctx, YSIZE*4);
        memcpy(EP, ctx+(260*4), PSIZE);

        for(i=0,j=0; i<NUMBLOCKSATONCE*8; i+=8)
		{
        u32 x0=(Y(j+185)&0xFF);
		    P(j+256)=P(j+x0);
		    P(j+x0)=P(j+0);
		    s+=Y(j+P(j+1+72));
		    s-=Y(j+P(j+1+239));
        s=ROTL32(s, 1);
		    Y(j+YMAXIND+1)=(s^Y(j+YMININD))+Y(j+P(j+1+153));
        s=ROTL32(s, 11);
        u32 output1=(s^Y(j+256))+Y(j+P(j+1+26));
        s=ROTL32(s, 7);
		    u32 output2=(s^Y(j-1))+Y(j+P(j+1+208));
		    ((u32*)(out+i))[0] = output1;
        ((u32*)(out+i+4))[0] = output2;
        j++;
		}
	
        memcpy(ctx, &EY[j], YSIZE*4);
        memcpy(ctx+(260*4), EP+j, PSIZE);
        ((u32*)ctx)[(260*4)+256]=s;
        length-=NUMBLOCKSATONCE*8;
        out+=NUMBLOCKSATONCE*8;
    }

    if(length>0)
    {
        memcpy(EY, ctx, YSIZE*4);
        memcpy(EP, ctx+(260*4), PSIZE);

        for(i=0,j=0; i<(length&(~7)); i+=8)
		{
        u32 x0=(Y(j+185)&0xFF);
		    P(j+256)=P(j+x0);
		    P(j+x0)=P(j+0);
		    s+=Y(j+P(j+1+72));
		    s-=Y(j+P(j+1+239));
		    s=ROTL32(s, 1);
		    Y(j+YMAXIND+1)=(s^Y(j+YMININD))+Y(j+P(j+1+153));
        s=ROTL32(s, 11);
        u32 output1=(s^Y(j+256))+Y(j+P(j+1+26));
        s=ROTL32(s, 7);
		    u32 output2=(s^Y(j-1))+Y(j+P(j+1+208));
		    ((u32*)(out+i))[0] = output1;
        ((u32*)(out+i+4))[0] = output2;
        j++;
		}

    if(length&7)
		{
		    int ii;   
		    u32 x0=(Y(j+185)&0xFF);
		    P(j+256)=P(j+x0);
		    P(j+x0)=P(j+0);
		    s+=Y(j+P(j+1+72));
		    s-=Y(j+P(j+1+239));
		    s=ROTL32(s, 1);
		    Y(j+YMAXIND+1)=(s^Y(j+YMININD))+Y(j+P(j+1+153));
        s=ROTL32(s, 11);
        u32 output1=(s^Y(j+256))+Y(j+P(j+1+26));
        s=ROTL32(s, 7);
		    u32 output2=(s^Y(j-1))+Y(j+P(j+1+208));
		    u8 outputb[8];
		    ((u32*)(outputb))[0] = output1;
        ((u32*)(outputb+4))[0] = output2;
		    for(ii=0; ii<(length&7); ii++) (out+i)[ii]=outputb[ii];
		}

        memcpy(ctx, &EY[j], YSIZE*4);
        memcpy(ctx+(260*4), EP+j, PSIZE);
        ((u32*)ctx)[(260*4)+256]=s;
    }

    mask();
    #undef P
    #undef Y
    return 0;
}

int crypto_stream_xor(
       unsigned char *out,
       const unsigned char *in,
       unsigned long long inlen,
       const unsigned char *n,
       const unsigned char *k
     )
{
    u8 ctx[(4*260)+256+4];
    setup(ctx, k, n);

    u64 msglen = inlen;

    u32 i,j;

    u32 s=((u32*)ctx)[260+(256/4)];
    u32 EY[YSIZE+NUMBLOCKSATONCE];
    u8 EP[PSIZE+NUMBLOCKSATONCE];
    #define Y(x) (EY[(x)-(YMININD)])
    #define P(x) (EP[(x)])
  
	while(msglen>=NUMBLOCKSATONCE*8)
    {
        memcpy(EY, ctx, YSIZE*4);
        memcpy(EP, ctx+(260*4), PSIZE);

        for(i=0,j=0; i<NUMBLOCKSATONCE*8; i+=8)
		{
		    u32 x0=(Y(j+185)&0xFF);
		    P(j+256)=P(j+x0);
		    P(j+x0)=P(j+0);
		    s+=Y(j+P(j+1+72));
		    s-=Y(j+P(j+1+239));
		    s=ROTL32(s, 1);
		    Y(j+YMAXIND+1)=(s^Y(j+YMININD))+Y(j+P(j+1+153));
        s=ROTL32(s, 11);
        u32 output1=(s^Y(j+256))+Y(j+P(j+1+26));
        s=ROTL32(s, 7);
		    u32 output2=(s^Y(j-1))+Y(j+P(j+1+208));
		    ((u32*)(out+i))[0]=output1^((u32*)(in+i))[0];
        ((u32*)(out+i+4))[0]=output2^((u32*)(in+i+4))[0];
        j++;	
		}

        memcpy(ctx, &EY[j], YSIZE*4);
        memcpy(ctx+(260*4), &EP[j], PSIZE);
        ((u32*)ctx)[260+(256/4)]=s;

        msglen-=NUMBLOCKSATONCE*8;
        in+=NUMBLOCKSATONCE*8;
        out+=NUMBLOCKSATONCE*8;
    }

    if(msglen>0)
    {
        memcpy(EY, ctx, YSIZE*4);
        memcpy(EP, ctx+(260*4), PSIZE);

        for(i=0,j=0; i<(msglen&(~7)); i+=8)
		{
		    u32 x0=(Y(j+185)&0xFF);
		    P(j+256)=P(j+x0);
		    P(j+x0)=P(j+0);
		    s+=Y(j+P(j+1+72));
		    s-=Y(j+P(j+1+239));
		    s=ROTL32(s, 1);
		    Y(j+YMAXIND+1)=(s^Y(j+YMININD))+Y(j+P(j+1+153));
        s=ROTL32(s, 11);
        u32 output1=(s^Y(j+256))+Y(j+P(j+1+26));
        s=ROTL32(s, 7);
		    u32 output2=(s^Y(j-1))+Y(j+P(j+1+208));
        ((u32*)(out+i))[0]=output1^((u32*)(in+i))[0];
        ((u32*)(out+i+4))[0]=output2^((u32*)(in+i+4))[0];
        j++;
		}

        if(msglen&7)
		{
		    u32 ii;
		    u32 x0=(Y(j+185)&0xFF);
		    P(j+256)=P(j+x0);
		    P(j+x0)=P(j+0);
		    s+=Y(j+P(j+1+72));
		    s-=Y(j+P(j+1+239));
		    s=ROTL32(s, 1);
		    Y(j+YMAXIND+1)=(s^Y(j+YMININD))+Y(j+P(j+1+153));
        s=ROTL32(s, 11);
        u32 output1=(s^Y(j+256))+Y(j+P(j+1+26));
        s=ROTL32(s, 7);
		    u32 output2=(s^Y(j-1))+Y(j+P(j+1+208));
		    u8 outputb[8];
		    ((u32*)(outputb))[0] = output1;
        ((u32*)(outputb+4))[0] = output2;
		    for(ii=0; ii<(msglen&7); ii++) (out+i)[ii]=outputb[ii]^(in+i)[ii];
		}

        memcpy(ctx, &EY[j], YSIZE*4);
        memcpy(ctx+(260*4), &EP[j], PSIZE);
        ((u32*)ctx)[260+(256/4)]=s;
    }

    mask();
    #undef P
    #undef Y

    return 0;
}

